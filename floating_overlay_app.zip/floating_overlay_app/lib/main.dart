import 'package:flutter/material.dart';
import 'screens/permission_screen.dart';

void main() {
  runApp(const FloatingOverlayApp());
}

class FloatingOverlayApp extends StatelessWidget {
  const FloatingOverlayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Floating Overlay App',
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const PermissionScreen(),
    );
  }
}
