import 'package:flutter/services.dart';

/// Thin Dart wrapper around the native MethodChannel / EventChannel.
/// All overlay rendering happens natively; this class is purely the
/// control-plane API used by the Flutter UI.
class OverlayService {
  OverlayService._();
  static final OverlayService instance = OverlayService._();

  static const _controlChannel = MethodChannel(
    'com.example.floating_overlay/control',
  );
  static const _eventChannel = EventChannel(
    'com.example.floating_overlay/events',
  );

  Stream<Map<String, dynamic>>? _eventStream;

  /// Stream of gesture/status events from the native overlay:
  /// {"type":"tap"} | {"type":"longPress"} | {"type":"swipe","dir":"up"} |
  /// {"type":"menuSelect","id":"..."} | {"type":"moved","x":..,"y":..}
  Stream<Map<String, dynamic>> get events {
    _eventStream ??= _eventChannel.receiveBroadcastStream().map(
          (event) => Map<String, dynamic>.from(event as Map),
        );
    return _eventStream!;
  }

  Future<bool> hasOverlayPermission() async {
    return await _controlChannel.invokeMethod<bool>('hasOverlayPermission') ??
        false;
  }

  Future<void> requestOverlayPermission() async {
    await _controlChannel.invokeMethod('requestOverlayPermission');
  }

  Future<bool> isAccessibilityEnabled() async {
    return await _controlChannel.invokeMethod<bool>(
          'isAccessibilityEnabled',
        ) ??
        false;
  }

  Future<void> openAccessibilitySettings() async {
    await _controlChannel.invokeMethod('openAccessibilitySettings');
  }

  Future<bool> isIgnoringBatteryOptimizations() async {
    return await _controlChannel.invokeMethod<bool>(
          'isIgnoringBatteryOptimizations',
        ) ??
        false;
  }

  Future<void> requestIgnoreBatteryOptimization() async {
    await _controlChannel.invokeMethod('requestIgnoreBatteryOptimization');
  }

  Future<void> openBatteryOptimizationSettingsList() async {
    await _controlChannel.invokeMethod('openBatteryOptimizationSettingsList');
  }

  Future<bool> startOverlay() async {
    return await _controlChannel.invokeMethod<bool>('startOverlay') ?? false;
  }

  Future<bool> stopOverlay() async {
    return await _controlChannel.invokeMethod<bool>('stopOverlay') ?? false;
  }

  Future<void> updateOverlayConfig({
    required double sizeDp,
    required double opacity,
  }) async {
    await _controlChannel.invokeMethod('updateOverlayConfig', {
      'sizeDp': sizeDp,
      'opacity': opacity,
    });
  }

  Future<void> setMenuItems(List<Map<String, String>> items) async {
    await _controlChannel.invokeMethod('setMenuItems', {'items': items});
  }
}
