import 'package:flutter/material.dart';
import '../services/overlay_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  double _sizeDp = 56;
  double _opacity = 1.0;

  final List<Map<String, String>> _menuItems = [
    {'id': 'home', 'label': 'Home'},
    {'id': 'back', 'label': 'Back'},
    {'id': 'close', 'label': 'Close'},
    {'id': 'settings', 'label': 'Settings'},
  ];

  Future<void> _apply() async {
    await OverlayService.instance.updateOverlayConfig(
      sizeDp: _sizeDp,
      opacity: _opacity,
    );
  }

  Future<void> _saveMenuItems() async {
    await OverlayService.instance.setMenuItems(_menuItems);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Overlay Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Button size: ${_sizeDp.round()} dp'),
          Slider(
            min: 32,
            max: 96,
            value: _sizeDp,
            onChanged: (v) => setState(() => _sizeDp = v),
            onChangeEnd: (_) => _apply(),
          ),
          const SizedBox(height: 16),
          Text('Transparency: ${(_opacity * 100).round()}%'),
          Slider(
            min: 0.15,
            max: 1.0,
            value: _opacity,
            onChanged: (v) => setState(() => _opacity = v),
            onChangeEnd: (_) => _apply(),
          ),
          const SizedBox(height: 24),
          const Text(
            'Radial menu items',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          ..._menuItems.map(
            (item) => ListTile(
              title: Text(item['label'] ?? ''),
              subtitle: Text('id: ${item['id']}'),
              dense: true,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Drag the button to reposition it anywhere on screen — its '
            'position is saved automatically.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _saveMenuItems,
            child: const Text('Save menu configuration'),
          ),
        ],
      ),
    );
  }
}
