import 'package:flutter/material.dart';
import '../services/overlay_service.dart';
import 'battery_optimization_screen.dart';
import 'home_screen.dart';

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen>
    with WidgetsBindingObserver {
  bool _hasOverlay = false;
  bool _hasAccessibility = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshStatus();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Re-check permission status whenever the user returns from Settings.
    if (state == AppLifecycleState.resumed) _refreshStatus();
  }

  Future<void> _refreshStatus() async {
    final overlay = await OverlayService.instance.hasOverlayPermission();
    final accessibility =
        await OverlayService.instance.isAccessibilityEnabled();
    if (!mounted) return;
    setState(() {
      _hasOverlay = overlay;
      _hasAccessibility = accessibility;
    });
  }

  @override
  Widget build(BuildContext context) {
    final allGranted = _hasOverlay && _hasAccessibility;

    return Scaffold(
      appBar: AppBar(title: const Text('Setup')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'This app needs two permissions to show the floating button '
            'over other apps.',
            style: TextStyle(fontSize: 15),
          ),
          const SizedBox(height: 24),
          _PermissionTile(
            title: 'Display over other apps',
            description:
                'Lets the floating button appear on top of your screen, '
                'even while using other apps.',
            granted: _hasOverlay,
            onTap: () async {
              await OverlayService.instance.requestOverlayPermission();
            },
          ),
          const SizedBox(height: 12),
          _PermissionTile(
            title: 'Accessibility service',
            description:
                'Lets the radial menu perform quick actions like Back and '
                'Home. This app does not read content from other apps.',
            granted: _hasAccessibility,
            onTap: () async {
              await OverlayService.instance.openAccessibilitySettings();
            },
          ),
          const SizedBox(height: 12),
          ListTile(
            leading: const Icon(Icons.battery_saver_outlined),
            title: const Text('Battery optimization (optional)'),
            subtitle: const Text(
              'Recommended so the floating button stays active in the '
              'background.',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const BatteryOptimizationScreen(),
              ),
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: allGranted
                ? () => Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const HomeScreen()),
                    )
                : null,
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  const _PermissionTile({
    required this.title,
    required this.description,
    required this.granted,
    required this.onTap,
  });

  final String title;
  final String description;
  final bool granted;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(
          granted ? Icons.check_circle : Icons.radio_button_unchecked,
          color: granted ? Colors.green : null,
        ),
        title: Text(title),
        subtitle: Text(description),
        trailing: granted ? null : const Icon(Icons.chevron_right),
        onTap: granted ? null : onTap,
      ),
    );
  }
}
