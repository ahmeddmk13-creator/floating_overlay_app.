import 'package:flutter/material.dart';
import '../services/overlay_service.dart';

/// Explains, in plain language, why battery-optimization exemption helps
/// the floating overlay stay alive, and offers both the direct-request
/// route and the safer "open settings list" route (Play-compliant, since
/// it doesn't force a direct dialog on unwilling users).
class BatteryOptimizationScreen extends StatefulWidget {
  const BatteryOptimizationScreen({super.key});

  @override
  State<BatteryOptimizationScreen> createState() =>
      _BatteryOptimizationScreenState();
}

class _BatteryOptimizationScreenState
    extends State<BatteryOptimizationScreen> {
  bool _ignoring = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final result =
        await OverlayService.instance.isIgnoringBatteryOptimizations();
    if (mounted) setState(() => _ignoring = result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Battery Optimization')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Icon(
            _ignoring ? Icons.check_circle : Icons.info_outline,
            size: 48,
            color: _ignoring ? Colors.green : Colors.orange,
          ),
          const SizedBox(height: 16),
          Text(
            _ignoring
                ? 'This app is already excluded from battery optimization.'
                : 'Android may pause the floating button in the '
                    'background to save power. Excluding this app from '
                    'battery optimization keeps it running reliably.',
            style: const TextStyle(fontSize: 15),
          ),
          const SizedBox(height: 24),
          const Text(
            'This step is optional — the app works without it, but the '
            'button may occasionally disappear until reopened.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 32),
          if (!_ignoring) ...[
            ElevatedButton(
              onPressed: () async {
                await OverlayService.instance
                    .requestIgnoreBatteryOptimization();
                await _check();
              },
              child: const Text('Exclude this app (recommended)'),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () async {
                await OverlayService.instance
                    .openBatteryOptimizationSettingsList();
                await _check();
              },
              child: const Text('Open battery settings manually'),
            ),
          ],
        ],
      ),
    );
  }
}
