import 'dart:async';
import 'package:flutter/material.dart';
import '../services/overlay_service.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _running = false;
  final List<String> _log = [];
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = OverlayService.instance.events.listen((event) {
      setState(() {
        _log.insert(0, event.toString());
        if (_log.length > 50) _log.removeLast();
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_running) {
      await OverlayService.instance.stopOverlay();
    } else {
      final started = await OverlayService.instance.startOverlay();
      if (!started && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Overlay permission not granted')),
        );
        return;
      }
    }
    setState(() => _running = !_running);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Floating Overlay'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: ElevatedButton.icon(
              icon: Icon(_running ? Icons.stop : Icons.play_arrow),
              label: Text(_running ? 'Stop floating button' : 'Start floating button'),
              onPressed: _toggle,
            ),
          ),
          const Divider(height: 1),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Gesture events',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _log.length,
              itemBuilder: (context, index) => ListTile(
                dense: true,
                title: Text(_log[index]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
