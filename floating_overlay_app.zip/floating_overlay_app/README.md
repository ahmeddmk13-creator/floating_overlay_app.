# Floating Overlay App — Technical Specification & Architecture

## Quick Build Instructions

**Option A — GitHub Actions (no local install needed):**
1. Push this whole folder's contents to a GitHub repository (the `.github/workflows/build_apk.yml` file must sit at `.github/workflows/build_apk.yml` in the repo root).
2. Go to the repo's **Actions** tab → select **Build APK** → **Run workflow**.
3. When it finishes (green check), open the run → scroll to **Artifacts** → download `app-release-apk`. That's your installable `.apk`.

**Option B — Local build (requires Flutter SDK + Android SDK installed):**
```bash
flutter pub get
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

Note: `android/gradlew`, `android/gradlew.bat`, and `android/gradle/wrapper/gradle-wrapper.jar`
are intentionally **not** included in this deliverable (they are binary/generated
files that shouldn't be hand-authored). The CI workflow generates them
automatically via `gradle wrapper --gradle-version 8.6` before building. If
building locally, run that same command inside `android/` first, or simply
run `flutter create --platforms=android .` once inside this project folder
to have Flutter regenerate them for you.

---


A production-grade Flutter application with a native Android backend that
draws a **system-wide floating overlay** (like Messenger "chat heads"),
backed by an **Accessibility Service**, with a draggable button, radial
gesture menu, adjustable size/transparency, and full permission handling.

---

## 1. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Flutter Layer (Dart)                    │
│  ─────────────────────────────────────────────────────────────  │
│  main.dart                                                       │
│   ├─ PermissionScreen   (overlay / accessibility / battery)      │
│   ├─ SettingsScreen     (size, opacity, position, menu items)    │
│   └─ HomeScreen         (start/stop overlay, status)             │
│                                                                   │
│  services/overlay_service.dart                                   │
│   └─ MethodChannel  "com.example.floating_overlay/control"       │
│   └─ EventChannel   "com.example.floating_overlay/events"        │
└───────────────────────────┬───────────────────────────────────────┘
                            │  platform channel (JSON-serializable)
┌───────────────────────────▼───────────────────────────────────────┐
│                      Native Android Layer (Kotlin)                │
│  ─────────────────────────────────────────────────────────────    │
│  MainActivity.kt                                                   │
│   └─ registers MethodChannel handlers, launches system settings    │
│      intents (overlay permission, accessibility settings,          │
│      battery-optimization whitelist)                               │
│                                                                     │
│  OverlayService.kt   (Foreground Service, type "specialUse")        │
│   ├─ WindowManager + TYPE_APPLICATION_OVERLAY                      │
│   ├─ FloatingButtonView (draggable, tap/long-press/swipe)           │
│   ├─ RadialMenuView (canvas-drawn radial menu)                     │
│   └─ persists position/size/alpha via SharedPreferences            │
│                                                                     │
│  OverlayAccessibilityService.kt                                    │
│   └─ AccessibilityService — global gesture dispatch, foreground-app │
│      awareness, optional auto-hide on certain apps                 │
│                                                                     │
│  OverlayEventBus.kt                                                 │
│   └─ Bridges native touch/gesture events back to Flutter via       │
│      EventChannel (StreamHandler)                                  │
└─────────────────────────────────────────────────────────────────────┘
```

**Design principle:** all overlay logic lives natively (a Dart isolate cannot
own a `WindowManager` surface reliably across app-kill/background states).
Flutter is the **control plane** — it configures, starts, stops, and
receives status/gesture callbacks. The **data plane** (the actual overlay
rendering, drag physics, gesture detection) is 100% native Kotlin, which is
what Google Play requires for a robust, low-latency floating UI anyway.

---

## 2. Feature-to-Component Map

| Feature                         | Component                                   |
|----------------------------------|----------------------------------------------|
| System-wide floating overlay     | `OverlayService` + `WindowManager`            |
| Draggable floating button        | `FloatingButtonView.onTouchListener`          |
| Adjustable size                  | `LayoutParams.width/height` + live scale      |
| Adjustable transparency          | `View.alpha` + `LayoutParams` update          |
| Custom position (save/restore)   | `SharedPreferences` in `OverlayPreferences`   |
| Tap gesture                      | `GestureDetector.SimpleOnGestureListener`     |
| Long-press gesture                | Opens `RadialMenuView`                        |
| Swipe gesture (4-directional)    | Velocity-based delta detection on `ACTION_UP` |
| Radial menu                      | `RadialMenuView` (custom `Canvas` drawing)    |
| Accessibility Service             | `OverlayAccessibilityService`                 |
| Permission handling              | `PermissionScreen` + native intents           |
| Battery optimization guide        | `BatteryOptimizationScreen`                   |
| Play Store compliance             | See §6                                        |

---

## 3. Permission Flow (Runtime)

1. **`SYSTEM_ALERT_WINDOW`** (draw overlays)
   - Not a runtime `requestPermissions()` permission — requires
     `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` intent.
   - Checked via `Settings.canDrawOverlays(context)`.
2. **Accessibility Service**
   - User must manually enable it in
     `Settings.ACTION_ACCESSIBILITY_SETTINGS` — cannot be auto-granted.
   - Checked by reading `Settings.Secure.ACCESSIBILITY_ENABLED` and the
     enabled-services string and matching this app's service id.
3. **Battery Optimization**
   - Optional but recommended so the foreground service isn't killed.
   - `Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` (direct-request
     intent) OR — for Play compliance — link to
     `Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS` (the safer,
     non-direct route; see §6).
4. **Notifications (Android 13+)**
   - `POST_NOTIFICATIONS` runtime permission, required because the overlay
     runs as a **foreground service**, which mandates a persistent
     notification.

The Flutter `PermissionScreen` presents these as three sequential,
human-readable steps with live status checks (polling `MethodChannel` on
resume via `WidgetsBindingObserver.didChangeAppLifecycleState`).

---

## 4. Gesture & Radial Menu Design

- **Tap** (`< 150ms`, movement `< 10dp`) → broadcast `onTap` event to
  Flutter (e.g., open the app, or a quick action).
- **Long-press** (`> 500ms`, movement `< 10dp`) → opens `RadialMenuView`
  centered on the button, with N configurable action items arranged in a
  circle (`360/N` degrees apart). Releasing over a wedge selects it;
  releasing outside cancels.
- **Swipe** (`ACTION_MOVE` delta `> 24dp` with dominant axis, released with
  velocity `> 400dp/s`) → resolves to `up | down | left | right`, sent as a
  distinct event (e.g., swipe-up = expand, swipe-down = minimize/hide).
- **Drag** (anything not classified as tap/long-press/swipe) → moves the
  overlay and persists the new `(x, y)` on `ACTION_UP`, clamped to screen
  bounds, with edge-snapping animation (optional, `SPRING` interpolator).

All thresholds are centralized in `GestureConfig.kt` so they're tunable
without touching the touch-handling logic.

---

## 5. Adjustable Size & Transparency

- **Size:** a `sizeDp` value (default 56dp) drives both the
  `LayoutParams.width/height` of the overlay window *and* the inner
  `ImageView`/icon scale, so hit-testing always matches the visible circle.
- **Transparency:** an `opacity` float (0.15–1.0) is applied via
  `View.setAlpha()`. To avoid the OS clipping touch input on very low alpha
  values (a common bug), the *touchable region* is kept at full opacity
  logic — alpha only affects rendering, not the touch-target size.
- Both values are exposed to Flutter via `updateOverlayConfig(size, opacity)`
  and instantly reflected without restarting the service.

---

## 6. Google Play Compliance Notes

Floating-overlay + Accessibility Service apps face **elevated Play Store
scrutiny**. Key requirements to pass review:

1. **`SYSTEM_ALERT_WINDOW` justification**
   - Must have a clear, primary use case *visible in the app itself*
     (Play policy prohibits overlay-only "utility" apps with no other
     function). Your Play Store listing and in-app onboarding must explain
     *why* the overlay exists.
2. **Accessibility Service Declaration Form**
   - Required at submission if you request `BIND_ACCESSIBILITY_SERVICE`.
     You must state the specific user-facing feature it enables (Google
     rejects services whose sole stated purpose is "monitoring" or
     "analytics"). Use the accessibility service **only** for the declared
     feature (e.g., gesture dispatch for the radial menu), not to log other
     apps' content.
3. **Foreground Service Type (Android 14 / API 34+)**
   - Overlay foreground services must declare
     `android:foregroundServiceType="specialUse"` in the manifest and
     provide a `PROPERTY_SPECIAL_USE_FOREGROUND_SERVICE_SUB_TYPE` string
     describing the use case, per Play's Foreground Service (specialUse)
     policy.
4. **Persistent notification required**
   - Android mandates a non-dismissible notification while the foreground
     service runs — this is not optional and must not be hidden or
     disguised.
5. **Battery optimization prompts**
   - Play policy discourages apps from *directly* triggering
     `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` unless the core function
     genuinely requires it (background overlay qualifies) — but you should
     still offer it as an *optional, explained* step, not force it at first
     launch. This project implements it as an explained, skippable step in
     `BatteryOptimizationScreen`.
6. **Data Safety Form**
   - Since the Accessibility Service technically *can* observe on-screen
     content, your Play Console Data Safety declaration must accurately
     reflect what data (if any) is read, stored, or transmitted. This
     reference implementation reads no accessibility event content — it
     only dispatches gestures — so declare accordingly if you keep that
     scope.
7. **No obfuscated permission requests**
   - Each permission screen in this project explains, in plain language,
     what the permission does and why — required by Play's "Prominent
     Disclosure" policy for sensitive permissions.

---

## 7. Project File Layout

```
floating_overlay_app/
├── pubspec.yaml
├── lib/
│   ├── main.dart
│   ├── services/
│   │   └── overlay_service.dart
│   └── screens/
│       ├── permission_screen.dart
│       ├── battery_optimization_screen.dart
│       ├── settings_screen.dart
│       └── home_screen.dart
└── android/
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── kotlin/com/example/floating_overlay_app/
        │   ├── MainActivity.kt
        │   ├── OverlayService.kt
        │   ├── FloatingButtonView.kt
        │   ├── RadialMenuView.kt
        │   ├── GestureConfig.kt
        │   ├── OverlayPreferences.kt
        │   └── OverlayAccessibilityService.kt
        └── res/
            ├── xml/accessibility_service_config.xml
            ├── values/strings.xml
            └── drawable/ic_overlay_button.xml
```

---

## 8. Method / Event Channel Contract

**MethodChannel** `com.example.floating_overlay/control`

| Method                         | Args                              | Returns              |
|--------------------------------|------------------------------------|-----------------------|
| `hasOverlayPermission`         | –                                   | `bool`                |
| `requestOverlayPermission`     | –                                   | –  (opens settings)   |
| `isAccessibilityEnabled`       | –                                   | `bool`                |
| `openAccessibilitySettings`    | –                                   | –                     |
| `isIgnoringBatteryOptimizations`| –                                  | `bool`                |
| `requestIgnoreBatteryOptimization` | –                              | –                     |
| `startOverlay`                 | –                                   | `bool` success        |
| `stopOverlay`                  | –                                   | `bool` success        |
| `updateOverlayConfig`          | `{sizeDp, opacity}`                | –                     |
| `setMenuItems`                 | `List<{id,label}>`                 | –                     |

**EventChannel** `com.example.floating_overlay/events` streams:
`{"type":"tap"}`, `{"type":"longPress"}`, `{"type":"swipe","dir":"up"}`,
`{"type":"menuSelect","id":"..."}`, `{"type":"moved","x":..,"y":..}`.

---
See the accompanying source files for the full implementation of every
component listed above.
