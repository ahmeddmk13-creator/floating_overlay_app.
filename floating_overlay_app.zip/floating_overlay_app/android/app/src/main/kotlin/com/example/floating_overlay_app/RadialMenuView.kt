package com.example.floating_overlay_app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * A full-screen transparent overlay View that draws a radial ("pie") menu
 * centered at [centerX], [centerY] with [items] arranged evenly around a
 * circle. Call [show] to animate it open; releasing a finger over a wedge
 * fires [onItemSelected]; releasing elsewhere fires [onDismiss].
 */
class RadialMenuView(
    context: Context,
    private val items: List<Pair<String, String>>, // id -> label
    private val onItemSelected: (String) -> Unit,
    private val onDismiss: () -> Unit
) : View(context) {

    var centerX: Float = 0f
    var centerY: Float = 0f

    private val innerRadiusDp = 40f
    private val outerRadiusDp = 130f
    private val density = context.resources.displayMetrics.density

    private val innerRadiusPx get() = innerRadiusDp * density
    private val outerRadiusPx get() = outerRadiusDp * density

    private var animatedFraction = 0f
    private var highlightedIndex = -1

    private val wedgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC1E1E1E")
        style = Paint.Style.FILL
    }
    private val wedgeHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E63A82F7")
        style = Paint.Style.FILL
    }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }

    fun show() {
        visibility = VISIBLE
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 160
            addUpdateListener {
                animatedFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun hide(after: () -> Unit) {
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 120
            addUpdateListener {
                animatedFraction = it.animatedValue as Float
                invalidate()
            }
            doOnEndCompat { after() }
            start()
        }
    }

    private fun ValueAnimator.doOnEndCompat(block: () -> Unit) {
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                block()
            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (items.isEmpty()) return
        val sweep = 360f / items.size
        val currentOuter = outerRadiusPx * animatedFraction
        val rect = RectF(
            centerX - currentOuter, centerY - currentOuter,
            centerX + currentOuter, centerY + currentOuter
        )

        items.forEachIndexed { index, (_, label) ->
            val startAngle = index * sweep - 90f - sweep / 2f
            val paint = if (index == highlightedIndex) wedgeHighlightPaint else wedgePaint
            canvas.drawArc(rect, startAngle, sweep, true, paint)
            canvas.drawArc(rect, startAngle, sweep, true, dividerPaint)

            // label position at mid-radius, mid-angle
            val midAngleRad = Math.toRadians((startAngle + sweep / 2f).toDouble())
            val midRadius = (innerRadiusPx + currentOuter) / 2f
            val lx = centerX + (midRadius * cos(midAngleRad)).toFloat()
            val ly = centerY + (midRadius * sin(midAngleRad)).toFloat() + textPaint.textSize / 3f
            canvas.drawText(label, lx, ly, textPaint)
        }

        // inner "cancel" circle
        canvas.drawCircle(centerX, centerY, innerRadiusPx * animatedFraction, wedgePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val dx = event.x - centerX
        val dy = event.y - centerY
        val distance = hypot(dx.toDouble(), dy.toDouble()).toFloat()

        when (event.action) {
            MotionEvent.ACTION_MOVE -> {
                highlightedIndex = if (distance < innerRadiusPx) {
                    -1
                } else {
                    indexForAngle(dx, dy)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val selected = if (distance in innerRadiusPx..outerRadiusPx) {
                    items.getOrNull(indexForAngle(dx, dy))?.first
                } else null

                hide {
                    visibility = GONE
                    if (selected != null) onItemSelected(selected) else onDismiss()
                }
            }
        }
        return true
    }

    private fun indexForAngle(dx: Float, dy: Float): Int {
        val sweep = 360f / items.size
        var angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        angleDeg = (angleDeg + 90f + sweep / 2f + 360f) % 360f
        return (angleDeg / sweep).toInt().coerceIn(0, items.size - 1)
    }
}
