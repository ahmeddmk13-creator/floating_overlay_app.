package com.example.floating_overlay_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

/**
 * Foreground Service that owns the WindowManager overlay surface for the
 * lifetime of the floating button. Started/stopped from MainActivity via
 * the MethodChannel. Emits gesture/status events through OverlayEventBus so
 * Flutter can react to taps, long-presses, swipes, and menu selections.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: OverlayPreferences
    private var buttonView: FloatingButtonView? = null
    private var radialMenuView: RadialMenuView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = OverlayPreferences(this)
        startForegroundWithNotification()
        addFloatingButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UPDATE_CONFIG -> {
                val sizeDp = intent.getFloatExtra(EXTRA_SIZE_DP, prefs.sizeDp)
                val opacity = intent.getFloatExtra(EXTRA_OPACITY, prefs.opacity)
                updateConfig(sizeDp, opacity)
            }
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeFloatingButton()
        super.onDestroy()
    }

    // ---- Overlay lifecycle -------------------------------------------------

    private fun addFloatingButton() {
        val density = resources.displayMetrics.density
        params = FloatingButtonView.buildLayoutParams(prefs.sizeDp, density).apply {
            x = prefs.posX
            y = prefs.posY
        }

        val view = FloatingButtonView(
            context = this,
            windowManager = windowManager,
            params = params,
            prefs = prefs,
            onTap = { OverlayEventBus.emit(mapOf("type" to "tap")) },
            onLongPress = { screenX, screenY -> showRadialMenu(screenX, screenY) },
            onSwipe = { direction ->
                OverlayEventBus.emit(mapOf("type" to "swipe", "dir" to direction.name.lowercase()))
            },
            onMoved = { x, y -> OverlayEventBus.emit(mapOf("type" to "moved", "x" to x, "y" to y)) }
        ).apply {
            setImageResource(R.drawable.ic_overlay_button)
            alpha = prefs.opacity
        }

        windowManager.addView(view, params)
        buttonView = view
    }

    private fun removeFloatingButton() {
        buttonView?.let { runCatching { windowManager.removeView(it) } }
        buttonView = null
        radialMenuView?.let { runCatching { windowManager.removeView(it) } }
        radialMenuView = null
    }

    private fun updateConfig(sizeDp: Float, opacity: Float) {
        val clampedSize = sizeDp.coerceIn(GestureConfig.MIN_SIZE_DP, GestureConfig.MAX_SIZE_DP)
        val clampedOpacity = opacity.coerceIn(GestureConfig.MIN_OPACITY, GestureConfig.MAX_OPACITY)
        prefs.sizeDp = clampedSize
        prefs.opacity = clampedOpacity

        val density = resources.displayMetrics.density
        val sizePx = (clampedSize * density).toInt()
        params.width = sizePx
        params.height = sizePx
        buttonView?.let {
            it.alpha = clampedOpacity
            windowManager.updateViewLayout(it, params)
        }
    }

    // ---- Radial menu --------------------------------------------------------

    private fun showRadialMenu(screenX: Float, screenY: Float) {
        if (radialMenuView != null) return

        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        val menu = RadialMenuView(
            context = this,
            items = prefs.menuItems(),
            onItemSelected = { id ->
                OverlayEventBus.emit(mapOf("type" to "menuSelect", "id" to id))
                removeRadialMenu()
            },
            onDismiss = { removeRadialMenu() }
        ).apply {
            centerX = screenX
            centerY = screenY
        }

        windowManager.addView(menu, menuParams)
        radialMenuView = menu
        menu.show()
    }

    private fun removeRadialMenu() {
        radialMenuView?.let { runCatching { windowManager.removeView(it) } }
        radialMenuView = null
    }

    // ---- Foreground notification --------------------------------------------

    private fun startForegroundWithNotification() {
        val channelId = "overlay_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating Button", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = Notification.Builder(this, channelId)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(R.drawable.ic_overlay_button)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val NOTIFICATION_ID = 4201
        const val ACTION_UPDATE_CONFIG = "com.example.floating_overlay_app.UPDATE_CONFIG"
        const val ACTION_STOP = "com.example.floating_overlay_app.STOP"
        const val EXTRA_SIZE_DP = "extra_size_dp"
        const val EXTRA_OPACITY = "extra_opacity"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, OverlayService::class.java).apply {
                action = ACTION_STOP
            })
        }

        fun updateConfig(context: Context, sizeDp: Float, opacity: Float) {
            context.startService(Intent(context, OverlayService::class.java).apply {
                action = ACTION_UPDATE_CONFIG
                putExtra(EXTRA_SIZE_DP, sizeDp)
                putExtra(EXTRA_OPACITY, opacity)
            })
        }
    }
}
