package com.example.floating_overlay_app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Thin wrapper around SharedPreferences that persists the overlay's last
 * known position, size, opacity, and configured radial-menu items so the
 * bubble reappears exactly where the user left it after a service restart.
 */
class OverlayPreferences(context: Context) {

    private val prefs = context.getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)

    var posX: Int
        get() = prefs.getInt("pos_x", 0)
        set(value) = prefs.edit().putInt("pos_x", value).apply()

    var posY: Int
        get() = prefs.getInt("pos_y", 200)
        set(value) = prefs.edit().putInt("pos_y", value).apply()

    var sizeDp: Float
        get() = prefs.getFloat("size_dp", GestureConfig.DEFAULT_SIZE_DP)
        set(value) = prefs.edit().putFloat("size_dp", value).apply()

    var opacity: Float
        get() = prefs.getFloat("opacity", GestureConfig.DEFAULT_OPACITY)
        set(value) = prefs.edit().putFloat("opacity", value).apply()

    /** Menu items stored as JSON: [{"id": "...", "label": "..."}, ...] */
    var menuItemsJson: String
        get() = prefs.getString("menu_items", defaultMenuItemsJson()) ?: defaultMenuItemsJson()
        set(value) = prefs.edit().putString("menu_items", value).apply()

    fun menuItems(): List<Pair<String, String>> {
        val arr = JSONArray(menuItemsJson)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            obj.getString("id") to obj.getString("label")
        }
    }

    private fun defaultMenuItemsJson(): String {
        val arr = JSONArray()
        listOf(
            "home" to "Home",
            "back" to "Back",
            "close" to "Close",
            "settings" to "Settings"
        ).forEach { (id, label) ->
            arr.put(JSONObject().apply {
                put("id", id)
                put("label", label)
            })
        }
        return arr.toString()
    }
}
