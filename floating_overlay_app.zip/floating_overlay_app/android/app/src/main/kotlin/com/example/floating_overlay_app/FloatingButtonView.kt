package com.example.floating_overlay_app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.abs

enum class SwipeDirection { UP, DOWN, LEFT, RIGHT }

/**
 * The draggable circular button drawn via WindowManager.TYPE_APPLICATION_OVERLAY.
 * Classifies raw touch input into tap / long-press / swipe / drag and
 * reports results through the provided callbacks. Dragging updates the
 * WindowManager LayoutParams live and persists the final position.
 */
class FloatingButtonView(
    context: Context,
    private val windowManager: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val prefs: OverlayPreferences,
    private val onTap: () -> Unit,
    private val onLongPress: (screenX: Float, screenY: Float) -> Unit,
    private val onSwipe: (SwipeDirection) -> Unit,
    private val onMoved: (x: Int, y: Int) -> Unit
) : ImageView(context) {

    private val density = context.resources.displayMetrics.density

    private var downRawX = 0f
    private var downRawY = 0f
    private var downParamX = 0
    private var downParamY = 0
    private var downTimeMs = 0L
    private var isDragging = false
    private var longPressFired = false

    private var velocityTracker: VelocityTracker? = null

    private val longPressRunnable = Runnable {
        if (!isDragging) {
            longPressFired = true
            performLongPressFeedback()
            onLongPress(downRawX, downRawY)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                downParamX = params.x
                downParamY = params.y
                downTimeMs = System.currentTimeMillis()
                isDragging = false
                longPressFired = false

                velocityTracker?.recycle()
                velocityTracker = VelocityTracker.obtain().also { it.addMovement(event) }

                postDelayed(longPressRunnable, GestureConfig.LONG_PRESS_MIN_DURATION_MS)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                velocityTracker?.addMovement(event)
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                val slopPx = GestureConfig.TOUCH_SLOP_DP * density

                if (!isDragging && (abs(dx) > slopPx || abs(dy) > slopPx)) {
                    isDragging = true
                    removeCallbacks(longPressRunnable)
                }

                if (isDragging && !longPressFired) {
                    params.x = downParamX + dx.toInt()
                    params.y = downParamY + dy.toInt()
                    clampToScreen()
                    windowManager.updateViewLayout(this, params)
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                velocityTracker?.addMovement(event)
                velocityTracker?.computeCurrentVelocity(1000) // px/sec

                val elapsed = System.currentTimeMillis() - downTimeMs
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                val distancePx = Math.hypot(dx.toDouble(), dy.toDouble())
                val slopPx = GestureConfig.TOUCH_SLOP_DP * density

                if (!longPressFired) {
                    val swipeDistancePx = GestureConfig.SWIPE_MIN_DISTANCE_DP * density
                    val swipeVelocityPxS = GestureConfig.SWIPE_MIN_VELOCITY_DPS * density
                    val vx = velocityTracker?.xVelocity ?: 0f
                    val vy = velocityTracker?.yVelocity ?: 0f

                    when {
                        // Tap: short duration, minimal movement
                        elapsed < GestureConfig.TAP_MAX_DURATION_MS && distancePx < slopPx -> {
                            onTap()
                        }
                        // Swipe: dominant-axis distance + velocity thresholds met
                        (abs(dx) > swipeDistancePx || abs(dy) > swipeDistancePx) &&
                            (abs(vx) > swipeVelocityPxS || abs(vy) > swipeVelocityPxS) -> {
                            onSwipe(resolveSwipeDirection(dx, dy))
                        }
                        // Otherwise: settle as a drag — persist final position
                        else -> {
                            persistPosition()
                            onMoved(params.x, params.y)
                        }
                    }
                } else {
                    // A long-press occurred; if the finger also moved beyond the
                    // menu region it's handled by RadialMenuView instead.
                    persistPosition()
                }

                velocityTracker?.recycle()
                velocityTracker = null
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun resolveSwipeDirection(dx: Float, dy: Float): SwipeDirection {
        return if (abs(dx) > abs(dy)) {
            if (dx > 0) SwipeDirection.RIGHT else SwipeDirection.LEFT
        } else {
            if (dy > 0) SwipeDirection.DOWN else SwipeDirection.UP
        }
    }

    private fun clampToScreen() {
        val metrics = context.resources.displayMetrics
        params.x = params.x.coerceIn(0, metrics.widthPixels - width)
        params.y = params.y.coerceIn(0, metrics.heightPixels - height)
    }

    private fun persistPosition() {
        prefs.posX = params.x
        prefs.posY = params.y
    }

    private fun performLongPressFeedback() {
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
    }

    companion object {
        /** Builds the default WindowManager.LayoutParams for the bubble. */
        fun buildLayoutParams(sizeDp: Float, density: Float): WindowManager.LayoutParams {
            val sizePx = (sizeDp * density).toInt()
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            return WindowManager.LayoutParams(
                sizePx, sizePx, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
            }
        }
    }
}
