package com.example.floating_overlay_app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

/**
 * Minimal, narrowly-scoped Accessibility Service.
 *
 * Scope, by design (see accessibility_service_config.xml):
 *  - canRetrieveWindowContent = false → cannot read other apps' UI/text.
 *  - Only used to dispatch system gestures (Back / Home / custom swipe
 *    paths) that the floating radial menu triggers, and to know when the
 *    foreground app changes so the bubble can optionally auto-hide.
 *
 * Keep this class's responsibilities limited to what your Play Store
 * "Accessibility Service Declaration Form" describes — expanding scope
 * (e.g., reading node content) requires updating that declaration.
 */
class OverlayAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally not inspecting event content — only used, if at all,
        // to detect a foreground-app change (event.packageName) for optional
        // auto-hide behavior. No text/node data is read or stored.
    }

    override fun onInterrupt() {
        // No-op: nothing to clean up since we don't hold open resources here.
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Dispatches a system Back action via the Accessibility gesture API. */
    fun performBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /** Dispatches a system Home action. */
    fun performHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /** Dispatches a synthetic swipe gesture at arbitrary screen coordinates. */
    fun dispatchSwipeGesture(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 200) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    companion object {
        /** Non-null only while the service is actually connected/enabled. */
        var instance: OverlayAccessibilityService? = null
            private set
    }
}
