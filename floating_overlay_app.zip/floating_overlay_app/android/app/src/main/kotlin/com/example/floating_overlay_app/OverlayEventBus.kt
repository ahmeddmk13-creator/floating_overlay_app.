package com.example.floating_overlay_app

import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.EventChannel

/**
 * Process-wide singleton that decouples OverlayService (which may keep
 * running even if MainActivity/Flutter engine is not currently attached)
 * from the EventChannel sink. When no Flutter engine is attached, emitted
 * events are simply dropped — nothing crashes.
 */
object OverlayEventBus : EventChannel.StreamHandler {

    private var sink: EventChannel.EventSink? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events
    }

    override fun onCancel(arguments: Any?) {
        sink = null
    }

    fun emit(data: Map<String, Any?>) {
        mainHandler.post {
            sink?.success(data)
        }
    }
}
