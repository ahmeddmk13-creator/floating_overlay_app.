package com.example.floating_overlay_app

/**
 * Centralized, tunable thresholds for tap / long-press / swipe / drag
 * classification. Keeping these in one place makes it easy to adjust feel
 * without touching touch-handling logic in FloatingButtonView.
 */
object GestureConfig {
    const val TAP_MAX_DURATION_MS = 150L
    const val LONG_PRESS_MIN_DURATION_MS = 500L
    const val TOUCH_SLOP_DP = 10f          // max movement to still count as tap/long-press
    const val SWIPE_MIN_DISTANCE_DP = 24f  // min dominant-axis movement to count as swipe
    const val SWIPE_MIN_VELOCITY_DPS = 400f // dp/second

    const val DEFAULT_SIZE_DP = 56f
    const val MIN_SIZE_DP = 32f
    const val MAX_SIZE_DP = 96f

    const val DEFAULT_OPACITY = 1.0f
    const val MIN_OPACITY = 0.15f
    const val MAX_OPACITY = 1.0f

    const val EDGE_SNAP_ENABLED = true
}
